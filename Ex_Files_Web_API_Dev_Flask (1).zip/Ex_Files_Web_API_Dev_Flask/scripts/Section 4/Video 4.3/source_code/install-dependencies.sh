#! /bin/sh

pip install flask
pip install mysql-python
pip install sqlalchemy
pip install PyLD