### Install Dependencies

For installing all the dependencies automatically please enter the following commands:

1. `chmod +x install-dependencies.sh`
1. `./install-dependencies.sh`


### Required packages

If you want to install dependencies separately, here is the list of needed dependencies:

1. pip install flask
1. pip install mysql-python
1. pip install sqlalchemy
1. pip install PyLD