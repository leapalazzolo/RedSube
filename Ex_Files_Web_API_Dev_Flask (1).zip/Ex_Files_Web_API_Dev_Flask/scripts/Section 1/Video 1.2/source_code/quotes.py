

def funny_quotes():
	return [{
			"author" : "Elbert Hubbard",
			"quote" : "Do not take life too seriously. You will never get out of it alive."
		},
		{
			"author" : "Mark Twain",
			"quote" : "Get your facts first, then you can distort them as you please."
		},
		{
			"author" : "Benjamin Franklin",
			"quote" : "Wine is constant proof that God loves us and loves to see us happy."
		},
		{
			"author" : "Winston Churchill",
			"quote" : "I may be drunk, Miss, but in the morning I will be sober and you will still be ugly."
		},
		{
			"author" : "Theodore Roosevelt",
			"quote" : "If you could kick the person in the pants responsible for most of your trouble, you wouldn't sit for a month."
		},
		{
			"author" : "Robin Williams",
			"quote" : "Why do they call it rush hour when nothing moves?"
		},
		{
			"author" : "Zsa Zsa Gabor",
			"quote" : "I am a marvelous housekeeper. Every time I leave a man I keep his house."
		},
		{
			"author" : "Arnold Schwarzenegger",
			"quote" : "It's simple, if it jiggles, it's fat."
		},
		{
			"author" : "Clint Eastwood",
			"quote" : "They say marriages are made in Heaven. But so is thunder and lightning."
		}
	]